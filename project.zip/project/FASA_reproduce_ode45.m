clear; clc; close all;

p = defaultParams();

tspan = (0:p.sampleTs:p.tf).';

q0  = [0.64; -0.75];       
dq0 = [2; -2.0];      
W0  = zeros(p.Nrbf, 2);
x0  = [q0; dq0; W0(:)];

odeOpt = odeset('RelTol', 1e-6, ...
                'AbsTol', 1e-8, ...
                'MaxStep', p.maxStep);

[t, X] = ode45(@(t, x) fasaOdeRhs(t, x, p), tspan, x0, odeOpt);

q  = X(:, 1:2).';
dq = X(:, 3:4).';
N  = numel(t);

qd    = zeros(2, N);
uLog  = zeros(2, N);
sLog  = zeros(2, N);
Wnorm = zeros(2, N);
xiLog = zeros(2, N);
xeLog = zeros(2, N);

for k = 1:N
    [qd(:, k), ~, ~] = desiredTrajectory(t(k));
    [~, aux] = fasaOdeRhsWithAux(t(k), X(k, :).', p);

    uLog(:, k)  = aux.u;
    sLog(:, k)  = aux.s;
    xiLog(:, k) = aux.xi;
    xeLog(:, k) = aux.xe;

    W = reshape(X(k, 5:end).', p.Nrbf, 2);
    Wnorm(:, k) = [norm(W(:, 1)); norm(W(:, 2))];
end

qe = q - qd;

resultDir = 'results_ode45';
if ~exist(resultDir, 'dir')
    mkdir(resultDir);
end

figure('Name', 'Fig.1 Trajectories of q and q_d, ode45');

subplot(2, 1, 1);
plot(t, q(1, :), 'LineWidth', 5); hold on;
plot(t, qd(1, :), '--', 'LineWidth', 5);
yline(p.abar(1), 'k:', 'LineWidth', 5);
yline(-p.a(1),   'k-.', 'LineWidth', 5);
grid on;
xlabel('t (s)','interpreter','latex');
ylabel('$q_1$ and $q_{d1}$ (rad)','interpreter','latex');
lgd=legend('$q_1$', '$q_{d1}$', '$\bar{a}_1$', '$\underline{a}_1$', 'interpreter','latex','fontsize',35);
lgd.ItemTokenSize = [40, 18];
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');

axes('Position',[0.50, 0.66, 0.22, 0.12]);
plot(t,q(1,:),'linewidth',4,'linestyle','-.'); box on; grid on
hold on
plot(t,qd(1,:),'linewidth',4,'linestyle',':');
yline(p.abar(1), ':', 'LineWidth', 4);
yline(-p.a(1), '-.', 'LineWidth', 4);
xlim([0,0.4]);
ylim([6.4*10^(-1),7.02*10^(-1)]);
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');

subplot(2, 1, 2);
plot(t, q(2, :), 'LineWidth', 5); hold on;
plot(t, qd(2, :), '--', 'LineWidth', 5);
yline(p.abar(2), 'k:', 'LineWidth', 5);
yline(-p.a(2),   'k-.', 'LineWidth', 5);
grid on;
xlabel('t (s)','interpreter','latex');
ylabel('$q_2$ and $q_{d2}$ (rad)','interpreter','latex');
lgd=legend('$q_2$', '$q_{d2}$', '$\bar{a}_2$', '$\underline{a}_2$','fontsize',35,'interpreter','latex');
lgd.ItemTokenSize = [40, 18];
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');

axes('Position',[0.50,0.2,0.2,0.1]);
plot(t,q(2,:),'linewidth',4,'linestyle','-.'); box on; grid on
hold on
plot(t,qd(2,:),'linewidth',4,'linestyle',':');
yline(p.abar(2), ':', 'LineWidth', 5);
yline(-p.a(2), '-.', 'LineWidth', 5);
xlim([0,0.4]);
ylim([-8.01*10^(-1),-7.4*10^(-1)]);
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');

saveas(gcf, fullfile(resultDir, 'Fig1_q_qd_ode45.png'));
saveas(gcf, fullfile(resultDir, 'Fig1_q_qd_ode45.fig'));

figure('Name', 'Fig.2 Tracking error, ode45');
plot(t, qe(1, :), 'LineWidth', 5); hold on;
plot(t, qe(2, :), '--','LineWidth', 5);
grid on;
xlabel('t (s)');
ylabel('Tracking error $\mbox{\boldmath $q$}_e$ (rad)','interpreter','latex');
lgd=legend('$q_{e1}$', '$q_{e2}$','interpreter','latex','fontsize',60);
lgd.ItemTokenSize = [40, 18];
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');
saveas(gcf, fullfile(resultDir, 'Fig2_tracking_error_ode45.png'));
saveas(gcf, fullfile(resultDir, 'Fig2_tracking_error_ode45.fig'));

figure('Name', 'Fig.3 RBFNN weight norms, ode45');
plot(t, Wnorm(1, :), 'LineWidth', 5); hold on;
plot(t, Wnorm(2, :), '--','LineWidth', 5);
grid on;
xlabel('t (s)','interpreter','latex');
ylabel('Norm of $\mbox{\boldmath $W$}_1$ and $\mbox{\boldmath $W$}_2$','interpreter','latex');
lgd=legend('$\|W_1\|$', '$\|W_2\|$','interpreter','latex','fontsize',60);
lgd.ItemTokenSize = [40, 18];
saveas(gcf, fullfile(resultDir, 'Fig3_W_norm_ode45.png'));
saveas(gcf, fullfile(resultDir, 'Fig3_W_norm_ode45.fig'));
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');

figure('Name', 'Fig.4 Control input, ode45');
plot(t, uLog(1, :), 'LineWidth', 5); hold on;
plot(t, uLog(2, :), ':','LineWidth', 5);
grid on;
xlabel('t (s)','interpreter','latex');
ylabel('Control input \mbox{\boldmath $u$} (N$\cdot$m)','interpreter','latex');
lgd=legend('$u_1$', '$u_2$', 'interpreter','latex','fontsize',60);
lgd.ItemTokenSize = [40, 18];
set(gca,'FontSize',30)
set(gca,'linewidth',1)
set(gca,'FontName','Times New Roman');
saveas(gcf, fullfile(resultDir, 'Fig4_control_input_ode45.png'));
saveas(gcf, fullfile(resultDir, 'Fig4_control_input_ode45.fig'));

save(fullfile(resultDir, 'FASA_ode45_data.mat'), ...
     't', 'X', 'q', 'dq', 'qd', 'qe', 'uLog', 'sLog', 'Wnorm', 'xiLog', 'xeLog', 'p');

fprintf('\n========== FASA ode45 simulation finished ==========\n');
fprintf('q1 range: [%.6f, %.6f], constraint: (%.2f, %.2f)\n', ...
        min(q(1, :)), max(q(1, :)), -p.a(1), p.abar(1));
fprintf('q2 range: [%.6f, %.6f], constraint: (%.2f, %.2f)\n', ...
        min(q(2, :)), max(q(2, :)), -p.a(2), p.abar(2));
fprintf('Final tracking error: qe1 = %.6g, qe2 = %.6g\n', qe(1, end), qe(2, end));
fprintf('Max |u1| = %.6f, Max |u2| = %.6f\n', max(abs(uLog(1, :))), max(abs(uLog(2, :))));
fprintf('Figures and MAT data are saved in ./%s\n', resultDir);

function p = defaultParams()
    p.tf       = 10;
    p.sampleTs = 1e-3;
    p.maxStep  = 1e-3;

    p.len1 = 1.0;
    p.len2 = 0.8;
    p.m1   = 0.5;
    p.m2   = 1.5;
    p.I1   = 5.0;
    p.I2   = 5.0;
    p.g    = 9.81;

    p.m10 = 0.6;
    p.m20 = 1.8;
    p.I10 = 6.0;
    p.I20 = 6.0;

    p.a    = [0.8; 0.8];
    p.abar = [0.7; 0.7];

    p.boundEps = 1e-7;

    p.beta1 = 0.259957;
    p.beta2 = 0.262379;
    p.beta3 = 2.532021;

    p.hA1 = 0.6;
    p.hA2 = 0.6;
    p.hA3 = 5.0;
    p.n1  = 0.5;
    p.n2  = 1.5;
    p.n3  = 0.5;
    p.n4  = 1.5;
    p.epsH = 1e-2;

    p.sigma = [0.5; 2.9];
    p.k     = [0.5; 2.9];

    p.Nrbf      = 12;
    p.rbfWidth  = 2.0;
    p.rbfDim = 10;
    p.rbfCenters = makeRbfCenters(p.Nrbf, p.rbfDim);

    p.uMax = Inf;
end

function dx = fasaOdeRhs(t, x, p)
    [dx, ~] = fasaOdeRhsWithAux(t, x, p);
end

function [dx, aux] = fasaOdeRhsWithAux(t, x, p)
    q  = x(1:2);
    dq = x(3:4);
    W  = reshape(x(5:end), p.Nrbf, 2);

    [qd, dqd, ddqd] = desiredTrajectory(t);

    [xi, A2diag, alpha] = fasaTransform(q, dq, p.a, p.abar, p.boundEps);
    [xid, A2dDiag, alphad] = fasaTransform(qd, dqd, p.a, p.abar, p.boundEps);

    xidot   = A2diag  .* dq;
    xidot_d = A2dDiag .* dqd;
    xiddot_d = alphad + A2dDiag .* ddqd;

    xe    = xi - xid;
    xedot = xidot - xidot_d;

    [H, dHdx] = slidingH(xe, p);
    s = xedot + H;

    Hdot = dHdx .* xedot;

    [M0, C0, G0] = robotDynamics(q, dq, p, true);

    A2mat  = diag(A2diag);
    Abar2  = diag(1 ./ A2diag);

    qdotFromSliding = Abar2 * (xidot_d + s - H);
    f1 = -A2mat * (M0 \ (C0 * qdotFromSliding)) ...
         + alpha + Hdot ...
         - A2mat * (M0 \ G0);

    z  = [q; dq; qd; dqd; ddqd];
    h  = rbfBasis(z, p);
    nn = W.' * h;

    v = -p.beta1 * sigpow(s, p.n3) ...
        -p.beta2 * sigpow(s, p.n4) ...
        -p.beta3 * s ...
        -f1 + xiddot_d - nn;

    u = M0 * (Abar2 * v);

    if isfinite(p.uMax)
        u = max(min(u, p.uMax), -p.uMax);
    end

    [M, C, G] = robotDynamics(q, dq, p, false);
    d = externalDisturbance(t);
    ddq = M \ (u + d - C * dq - G);

    dW = zeros(p.Nrbf, 2);
    for i = 1:2
        dW(:, i) = (h * s(i) - p.k(i) * W(:, i)) / p.sigma(i);
    end

    dx = [dq; ddq; dW(:)];

    aux.u      = u;
    aux.s      = s;
    aux.xi     = xi;
    aux.xe     = xe;
    aux.H      = H;
    aux.h      = h;
    aux.nn     = nn;
    aux.qd     = qd;
    aux.dqd    = dqd;
    aux.ddqd   = ddqd;
end

function [qd, dqd, ddqd] = desiredTrajectory(t)
    qd = [0.6  * sin(0.3 * t);
          0.55 * sin(0.3 * t)];

    dqd = [0.6  * 0.3 * cos(0.3 * t);
           0.55 * 0.3 * cos(0.3 * t)];

    ddqd = [-0.6  * 0.3^2 * sin(0.3 * t);
            -0.55 * 0.3^2 * sin(0.3 * t)];
end

function d = externalDisturbance(t)
    d = [0.01 * sin(0.05 * t);
         0.01 * cos(0.05 * t)];
end

function [xi, A2diag, alpha] = fasaTransform(q, dq, a, abar, boundEps)
    qSafe = min(max(q, -a + boundEps), abar - boundEps);

    xi = a .* abar .* qSafe ./ ((a + qSafe) .* (abar - qSafe));

    A2diag = a .* abar .* (a .* abar + qSafe.^2) ...
        ./ ((a + qSafe).^2 .* (abar - qSafe).^2);

    alpha = 2 .* a .* abar ...
        .* (3 .* a .* abar .* qSafe + qSafe.^3 - a .* abar.^2 + a.^2 .* abar) ...
        .* dq.^2 ./ ((a + qSafe).^3 .* (abar - qSafe).^3);
end

function [H, dHdx] = slidingH(xe, p)
    H     = zeros(size(xe));
    dHdx  = zeros(size(xe));
    epsH  = p.epsH;

    l1 = 0.5 * p.hA1 * (3 - p.n1) * epsH^(p.n1 - 1) ...
       + 0.5 * p.hA2 * (3 - p.n2) * epsH^(p.n2 - 1);

    l2 = 0.5 * p.hA1 * (p.n1 - 1) * epsH^(p.n1 - 3) ...
       + 0.5 * p.hA2 * (p.n2 - 1) * epsH^(p.n2 - 3);

    for i = 1:numel(xe)
        if abs(xe(i)) >= epsH
            H(i) = p.hA1 * sigpow(xe(i), p.n1) ...
                 + p.hA2 * sigpow(xe(i), p.n2) ...
                 + p.hA3 * xe(i);

            dHdx(i) = p.hA1 * p.n1 * abs(xe(i))^(p.n1 - 1) ...
                    + p.hA2 * p.n2 * abs(xe(i))^(p.n2 - 1) ...
                    + p.hA3;
        else
            H(i)    = l1 * xe(i) + l2 * xe(i)^3 + p.hA3 * xe(i);
            dHdx(i) = l1 + 3 * l2 * xe(i)^2 + p.hA3;
        end
    end
end

function y = sigpow(x, r)
    y = sign(x) .* abs(x).^r;
end

function h = rbfBasis(z, p)
    z = z(:).';
    diff = p.rbfCenters - repmat(z, p.Nrbf, 1);
    h = exp(-sum(diff.^2, 2) / (p.rbfWidth^2));
end

function C = makeRbfCenters(Nrbf, dim)
    vals = linspace(-2, 2, Nrbf).';
    C = repmat(vals, 1, dim);
end

function [M, C, G] = robotDynamics(q, dq, p, useNominal)
    if useNominal
        m1 = p.m10; m2 = p.m20; I1 = p.I10; I2 = p.I20;
    else
        m1 = p.m1;  m2 = p.m2;  I1 = p.I1;  I2 = p.I2;
    end

    l1 = p.len1;
    l2 = p.len2;
    g  = p.g;

    q1  = q(1);
    q2  = q(2);
    dq1 = dq(1);
    dq2 = dq(2);

    M11 = (m1 + m2) * l1^2 + m2 * l2^2 + 2 * m2 * l1 * l2 * cos(q2) + I1;
    M12 = m2 * l2^2 + m2 * l1 * l2 * cos(q2);
    M22 = m2 * l2^2 + I2;
    M = [M11, M12;
         M12, M22];

    C11 = -2 * m2 * l1 * l2 * sin(q2) * dq2;
    C12 = -m2 * l1 * l2 * sin(q2) * dq2;
    C21 =  m2 * l1 * l2 * sin(q2) * dq1;
    C22 = 0;
    C = [C11, C12;
         C21, C22];

    G1 = (m1 + m2) * g * l1 * cos(q1) + m2 * g * l2 * cos(q1 + q2);
    G2 = m2 * l2 * g * cos(q1 + q2);
    G = [G1; G2];
end