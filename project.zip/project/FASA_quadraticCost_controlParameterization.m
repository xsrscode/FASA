clear; clc; close all;

p = defaultParams();

betaPaper = [0.259957, 0.262379, 2.532021];
beta0 = betaPaper;

lb = [0.05, 0.05, 0.10];
ub = [5.00, 5.00, 20.0];

opt = struct();
opt.tf       = 10;
opt.sampleTs = 1e-3;
opt.maxStep  = 1e-3;

opt.q0  = [0.64; -0.75];
opt.dq0 = [2.0; -2.0];

opt.dqMax = [Inf; Inf];
opt.uMax  = [Inf; Inf];

opt.Q = diag([1, 1]);
opt.R = 1e-4 * diag([1, 1]);

opt.constraintPenalty = 1e8;
opt.divergencePenalty = 1e12;

history = struct();
history.beta = [];
history.J = [];
assignin('base', 'history', history);

resultDir = 'results_quadraticCost_opt';
if ~exist(resultDir, 'dir')
    mkdir(resultDir);
end

fprintf('\n========== FASA quadratic-cost beta optimization ==========\n');
fprintf('Initial beta: [%.6f, %.6f, %.6f]\n', beta0);
fprintf('Paper beta  : [%.6f, %.6f, %.6f]\n', betaPaper);

[J_beta0, logBeta0] = quadraticCostObjective(beta0, p, opt, true);
[J_paper, logPaper] = quadraticCostObjective(betaPaper, p, opt, true);

fprintf('J(beta0)    = %.8e\n', J_beta0);
fprintf('J(betaPaper)= %.8e\n', J_paper);

obj = @(beta) quadraticCostObjectiveWithHistory(beta, p, opt);

if exist('fmincon', 'file') == 2
    options = optimoptions('fmincon', ...
        'Algorithm', 'sqp', ...
        'Display', 'iter', ...
        'MaxIterations', 60, ...
        'MaxFunctionEvaluations', 300, ...
        'StepTolerance', 1e-6, ...
        'OptimalityTolerance', 1e-6, ...
        'FiniteDifferenceType', 'central', ...
        'OutputFcn', @fminconOutputHistory);

    problem = struct();
    problem.objective = obj;
    problem.x0 = beta0;
    problem.lb = lb;
    problem.ub = ub;
    problem.solver = 'fmincon';
    problem.options = options;

    [betaOpt, Jopt, exitflag, output] = fmincon(problem);
else
    warning('fmincon not found. Use fminsearch with bounded sigmoid transformation.');

    y0 = betaToUnconstrained(beta0, lb, ub);
    objY = @(y) obj(unconstrainedToBeta(y, lb, ub));

    options = optimset('Display', 'iter', ...
                       'MaxIter', 100, ...
                       'MaxFunEvals', 400, ...
                       'TolX', 1e-5, ...
                       'TolFun', 1e-6);

    [yOpt, Jopt, exitflag, output] = fminsearch(objY, y0, options);
    betaOpt = unconstrainedToBeta(yOpt, lb, ub);
end

[Jverify, logOpt] = quadraticCostObjective(betaOpt, p, opt, true);

history = evalin('base', 'history');

fprintf('\n========== Optimization finished ==========\n');
fprintf('beta0    = [%.9f, %.9f, %.9f]\n', beta0);
fprintf('betaPaper= [%.9f, %.9f, %.9f]\n', betaPaper);
fprintf('betaOpt  = [%.9f, %.9f, %.9f]\n', betaOpt);
fprintf('J(beta0)     = %.8e\n', J_beta0);
fprintf('J(betaPaper) = %.8e\n', J_paper);
fprintf('J(betaOpt)   = %.8e\n', Jverify);
fprintf('exitflag     = %d\n', exitflag);

save(fullfile(resultDir, 'FASA_beta_quadraticCost_optimization_result.mat'), ...
     'beta0', 'betaPaper', 'betaOpt', ...
     'J_beta0', 'J_paper', 'Jopt', 'Jverify', ...
     'logBeta0', 'logPaper', 'logOpt', ...
     'p', 'opt', 'history', 'exitflag', 'output');

if ~isempty(history.J)
    figure('Name', 'Beta optimization history');
    semilogy(history.J, 'LineWidth', 1.2);
    grid on;
    xlabel('Function evaluation');
    ylabel('J_0 = \int(q_e^TQq_e + u^TRu)dt');
    title('Control parameterization optimization history with quadratic cost');
    saveas(gcf, fullfile(resultDir, 'Fig_beta_quadraticCost_optimization_history.png'));
    saveas(gcf, fullfile(resultDir, 'Fig_beta_quadraticCost_optimization_history.fig'));
end

figure('Name', 'Optimized beta tracking performance');

subplot(2,1,1);
plot(logOpt.t, logOpt.q(1,:), 'LineWidth', 1.2); hold on;
plot(logOpt.t, logOpt.qd(1,:), '--', 'LineWidth', 1.2);
yline(p.abar(1), 'k-.', 'LineWidth', 1.0);
yline(-p.a(1), 'k-.', 'LineWidth', 1.0);
grid on;
xlabel('t (s)');
ylabel('q_1, q_{d1} (rad)');
legend('q_1', 'q_{d1}', 'upper bound', 'lower bound', 'Location', 'best');
title('Joint 1 tracking after beta optimization');

subplot(2,1,2);
plot(logOpt.t, logOpt.q(2,:), 'LineWidth', 1.2); hold on;
plot(logOpt.t, logOpt.qd(2,:), '--', 'LineWidth', 1.2);
yline(p.abar(2), 'k-.', 'LineWidth', 1.0);
yline(-p.a(2), 'k-.', 'LineWidth', 1.0);
grid on;
xlabel('t (s)');
ylabel('q_2, q_{d2} (rad)');
legend('q_2', 'q_{d2}', 'upper bound', 'lower bound', 'Location', 'best');
title('Joint 2 tracking after beta optimization');

saveas(gcf, fullfile(resultDir, 'Fig_beta_quadraticCost_optimized_tracking.png'));
saveas(gcf, fullfile(resultDir, 'Fig_beta_quadraticCost_optimized_tracking.fig'));

figure('Name', 'Optimized beta error and input');

subplot(2,1,1);
plot(logOpt.t, logOpt.qe(1,:), 'LineWidth', 1.2); hold on;
plot(logOpt.t, logOpt.qe(2,:), 'LineWidth', 1.2);
grid on;
xlabel('t (s)');
ylabel('q_e (rad)');
legend('q_{e1}', 'q_{e2}', 'Location', 'best');
title('Tracking error after beta optimization');

subplot(2,1,2);
plot(logOpt.t, logOpt.uLog(1,:), 'LineWidth', 1.2); hold on;
plot(logOpt.t, logOpt.uLog(2,:), 'LineWidth', 1.2);
grid on;
xlabel('t (s)');
ylabel('u (N m)');
legend('u_1', 'u_2', 'Location', 'best');
title('Control input after beta optimization');

saveas(gcf, fullfile(resultDir, 'Fig_beta_quadraticCost_optimized_input.png'));
saveas(gcf, fullfile(resultDir, 'Fig_beta_quadraticCost_optimized_input.fig'));

fprintf('\nResults saved in ./%s\n', resultDir);

function J = quadraticCostObjectiveWithHistory(beta, p, opt)
    [J, ~] = quadraticCostObjective(beta, p, opt, false);

    history = evalin('base', 'history');
    history.beta = [history.beta; beta(:).'];
    history.J = [history.J; J];
    assignin('base', 'history', history);

    fprintf('J = %.8e, beta = [%.6f %.6f %.6f]\n', J, beta(1), beta(2), beta(3));
end

function [J, logData] = quadraticCostObjective(beta, p, opt, keepLog)

    if any(~isfinite(beta)) || any(beta <= 0)
        J = opt.divergencePenalty;
        logData = [];
        return;
    end

    tspan = (0:opt.sampleTs:opt.tf).';
    x0 = [opt.q0; opt.dq0];

    odeOpt = odeset('RelTol', 1e-6, ...
                    'AbsTol', 1e-8, ...
                    'MaxStep', opt.maxStep);

    try
        [t, X] = ode45(@(t,x) nominalClosedLoopRhs(t, x, p, beta), tspan, x0, odeOpt);
    catch
        J = opt.divergencePenalty;
        logData = [];
        return;
    end

    if isempty(X) || any(~isfinite(X(:))) || size(X,1) < 5
        J = opt.divergencePenalty;
        logData = [];
        return;
    end

    q  = X(:,1:2).';
    dq = X(:,3:4).';
    N  = numel(t);

    qd   = zeros(2,N);
    qe   = zeros(2,N);
    uLog = zeros(2,N);
    sLog = zeros(2,N);

    failed = false;
    for k = 1:N
        [qd(:,k), ~, ~] = desiredTrajectory(t(k));
        qe(:,k) = q(:,k) - qd(:,k);

        try
            aux = nominalControlAux(t(k), X(k,:).', p, beta);
            uLog(:,k) = aux.u;
            sLog(:,k) = aux.s;
        catch
            failed = true;
            break;
        end
    end

    if failed || any(~isfinite(uLog(:))) || any(~isfinite(sLog(:)))
        J = opt.divergencePenalty;
        logData = [];
        return;
    end

    trackingIntegrand = zeros(1, N);
    controlIntegrand  = zeros(1, N);

    for k = 1:N
        ek = qe(:, k);
        uk = uLog(:, k);
        trackingIntegrand(k) = ek.' * opt.Q * ek;
        controlIntegrand(k)  = uk.' * opt.R * uk;
    end

    J_tracking = trapz(t, trackingIntegrand);
    J_control  = trapz(t, controlIntegrand);
    J0 = J_tracking + J_control;

    upperViolation = max(q - p.abar, 0);
    lowerViolation = max(-p.a - q, 0);
    J_qConstraint = trapz(t, sum(upperViolation.^2 + lowerViolation.^2, 1));

    if all(isfinite(opt.dqMax))
        dqViolation = max(abs(dq) - opt.dqMax, 0);
        J_dqConstraint = trapz(t, sum(dqViolation.^2, 1));
    else
        J_dqConstraint = 0;
    end

    if all(isfinite(opt.uMax))
        uViolation = max(abs(uLog) - opt.uMax, 0);
        J_uConstraint = trapz(t, sum(uViolation.^2, 1));
    else
        J_uConstraint = 0;
    end

    if max(abs(q(:))) > 20 || max(abs(dq(:))) > 200 || max(abs(uLog(:))) > 1e6
        J_divergence = opt.divergencePenalty;
    else
        J_divergence = 0;
    end

    J = J0 ...
      + opt.constraintPenalty * (J_qConstraint + J_dqConstraint + J_uConstraint) ...
      + J_divergence;

    if ~isfinite(J)
        J = opt.divergencePenalty;
    end

    if keepLog
        logData = struct();
        logData.t = t;
        logData.X = X;
        logData.q = q;
        logData.dq = dq;
        logData.qd = qd;
        logData.qe = qe;
        logData.uLog = uLog;
        logData.sLog = sLog;
        logData.beta = beta;
        logData.J = J;
        logData.J0 = J0;
        logData.J_tracking = J_tracking;
        logData.J_control = J_control;
        logData.penalty = struct( ...
            'qConstraint', J_qConstraint, ...
            'dqConstraint', J_dqConstraint, ...
            'uConstraint', J_uConstraint, ...
            'divergence', J_divergence);
    else
        logData = [];
    end
end

function dx = nominalClosedLoopRhs(t, x, p, beta)

    q  = x(1:2);
    dq = x(3:4);

    aux = nominalControlAux(t, x, p, beta);
    u = aux.u;

    [M0, C0, G0] = robotDynamics(q, dq, p, true);
    ddq = M0 \ (u - C0*dq - G0);

    dx = [dq; ddq];
end

function aux = nominalControlAux(t, x, p, beta)

    q  = x(1:2);
    dq = x(3:4);

    [qd, dqd, ddqd] = desiredTrajectory(t);

    [xi, A2diag, alpha] = fasaTransform(q, dq, p.a, p.abar, p.boundEps);

    [xid, A2dDiag, alphad] = fasaTransform(qd, dqd, p.a, p.abar, p.boundEps);

    xidot   = A2diag  .* dq;
    xidot_d = A2dDiag .* dqd;
    xiddot_d = alphad + A2dDiag .* ddqd;

    xe    = xi - xid;
    xedot = xidot - xidot_d;

    [H, dHdx] = slidingH(xe, p);
    s = xedot + H;
    Hdot = dHdx .* xedot;

    [M0, C0, G0] = robotDynamics(q, dq, p, true);

    A2mat = diag(A2diag);
    Abar2 = diag(1 ./ A2diag);

    qdotFromSliding = Abar2 * (xidot_d + s - H);
    f1 = -A2mat * (M0 \ (C0 * qdotFromSliding)) ...
         + alpha + Hdot ...
         - A2mat * (M0 \ G0);

    v = -beta(1) * sigpow(s, p.n3) ...
        -beta(2) * sigpow(s, p.n4) ...
        -beta(3) * s ...
        -f1 + xiddot_d;

    u = M0 * (Abar2 * v);

    aux.u = u;
    aux.s = s;
    aux.xe = xe;
    aux.qd = qd;
    aux.dqd = dqd;
    aux.ddqd = ddqd;
end

function stop = fminconOutputHistory(beta, optimValues, state)
    stop = false;

    if strcmp(state, 'iter') || strcmp(state, 'init')
        history = evalin('base', 'history');
        history.beta = [history.beta; beta(:).'];
        history.J = [history.J; optimValues.fval];
        assignin('base', 'history', history);
    end
end

function y = betaToUnconstrained(beta, lb, ub)
    ratio = (beta - lb) ./ (ub - beta);
    ratio = max(ratio, 1e-12);
    y = log(ratio);
end

function beta = unconstrainedToBeta(y, lb, ub)
    beta = lb + (ub - lb) ./ (1 + exp(-y));
end

function p = defaultParams()

    p.tf       = 10;
    p.sampleTs = 1e-3;
    p.maxStep  = 1e-3;

    p.len1 = 1.0;
    p.len2 = 0.8;
    p.m1   = 0.5;
    p.m2   = 1.5;
    p.I1   = 5.0;
    p.I2   = 5.0;
    p.g    = 9.81;

    p.m10 = 0.6;
    p.m20 = 1.8;
    p.I10 = 6.0;
    p.I20 = 6.0;

    p.a    = [0.8; 0.8];
    p.abar = [0.7; 0.7];

    p.boundEps = 1e-7;

    p.hA1 = 0.6;
    p.hA2 = 0.6;
    p.hA3 = 5.0;
    p.n1  = 0.5;
    p.n2  = 1.5;
    p.n3  = 0.5;
    p.n4  = 1.5;

    p.epsH = 1e-4;
end

function [qd, dqd, ddqd] = desiredTrajectory(t)
    qd = [0.6  * sin(0.3 * t);
          0.55 * sin(0.3 * t)];

    dqd = [0.6  * 0.3 * cos(0.3 * t);
           0.55 * 0.3 * cos(0.3 * t)];

    ddqd = [-0.6  * 0.3^2 * sin(0.3 * t);
            -0.55 * 0.3^2 * sin(0.3 * t)];
end

function [xi, A2diag, alpha] = fasaTransform(q, dq, a, abar, boundEps)

    qSafe = min(max(q, -a + boundEps), abar - boundEps);

    xi = a .* abar .* qSafe ./ ((a + qSafe) .* (abar - qSafe));

    A2diag = a .* abar .* (a .* abar + qSafe.^2) ...
        ./ ((a + qSafe).^2 .* (abar - qSafe).^2);

    alpha = 2 .* a .* abar ...
        .* (3 .* a .* abar .* qSafe + qSafe.^3 - a .* abar.^2 + a.^2 .* abar) ...
        .* dq.^2 ./ ((a + qSafe).^3 .* (abar - qSafe).^3);
end

function [H, dHdx] = slidingH(xe, p)

    H    = zeros(size(xe));
    dHdx = zeros(size(xe));
    epsH = p.epsH;

    l1 = 0.5 * p.hA1 * (3 - p.n1) * epsH^(p.n1 - 1) ...
       + 0.5 * p.hA2 * (3 - p.n2) * epsH^(p.n2 - 1);

    l2 = 0.5 * p.hA1 * (p.n1 - 1) * epsH^(p.n1 - 3) ...
       + 0.5 * p.hA2 * (p.n2 - 1) * epsH^(p.n2 - 3);

    for i = 1:numel(xe)
        if abs(xe(i)) >= epsH
            H(i) = p.hA1 * sigpow(xe(i), p.n1) ...
                 + p.hA2 * sigpow(xe(i), p.n2) ...
                 + p.hA3 * xe(i);

            dHdx(i) = p.hA1 * p.n1 * abs(xe(i))^(p.n1 - 1) ...
                    + p.hA2 * p.n2 * abs(xe(i))^(p.n2 - 1) ...
                    + p.hA3;
        else
            H(i)    = l1 * xe(i) + l2 * xe(i)^3 + p.hA3 * xe(i);
            dHdx(i) = l1 + 3 * l2 * xe(i)^2 + p.hA3;
        end
    end
end

function y = sigpow(x, r)
    y = sign(x) .* abs(x).^r;
end

function [M, C, G] = robotDynamics(q, dq, p, useNominal)

    if useNominal
        m1 = p.m10; m2 = p.m20; I1 = p.I10; I2 = p.I20;
    else
        m1 = p.m1;  m2 = p.m2;  I1 = p.I1;  I2 = p.I2;
    end

    l1 = p.len1;
    l2 = p.len2;
    g  = p.g;

    q1  = q(1);
    q2  = q(2);
    dq1 = dq(1);
    dq2 = dq(2);

    M11 = (m1 + m2) * l1^2 + m2 * l2^2 + 2 * m2 * l1 * l2 * cos(q2) + I1;
    M12 = m2 * l2^2 + m2 * l1 * l2 * cos(q2);
    M22 = m2 * l2^2 + I2;

    M = [M11, M12;
         M12, M22];

    C11 = -2 * m2 * l1 * l2 * sin(q2) * dq2;
    C12 = -m2 * l1 * l2 * sin(q2) * dq2;
    C21 =  m2 * l1 * l2 * sin(q2) * dq1;
    C22 = 0;

    C = [C11, C12;
         C21, C22];

    G1 = (m1 + m2) * g * l1 * cos(q1) + m2 * g * l2 * cos(q1 + q2);
    G2 = m2 * l2 * g * cos(q1 + q2);

    G = [G1; G2];
end